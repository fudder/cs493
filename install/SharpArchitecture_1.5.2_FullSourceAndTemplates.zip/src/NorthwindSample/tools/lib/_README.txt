Folder containing tool and other non-deployable dependencies.

Your generated project will have the tool dependencies within this folder.  For keeping the S#arp Architecture download size to a minimum, you will need to copy the file in the root bin folder on the trunk.