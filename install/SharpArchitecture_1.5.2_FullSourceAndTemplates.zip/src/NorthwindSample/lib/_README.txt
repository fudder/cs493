Folder containing deployable project dependencies.

Your generated project will have the dependencies within this folder.  For keeping the S#arp Architecture download size to a minimum, you will need to copy the files from the root bin folder on the trunk.