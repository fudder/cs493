﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Northwind.Data")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyProduct("Northwind.Data")]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("286c82b1-5b6a-461b-af83-7dbeba08b634")]
