﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Northwind.ApplicationServices")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyProduct("Northwind.ApplicationServices")]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("2f49d2bf-666f-4527-99a9-5864f84ff326")]
