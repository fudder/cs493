﻿namespace Northwind.Web.Controllers
{
    public class ControllerEnums
    {
        public enum GlobalViewDataProperty
        {
            PageMessage
        }
    }
}
