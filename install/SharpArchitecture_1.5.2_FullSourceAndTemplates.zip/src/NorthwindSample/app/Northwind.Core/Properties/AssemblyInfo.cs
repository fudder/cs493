﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Northwind.Core")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyProduct("Northwind.Core")]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("d87e8032-116d-4c66-8366-102b3bb19852")]
