﻿using System.Reflection;

[assembly: AssemblyTitle("SharpArch.Core.NHibernateValidator")]
[assembly: AssemblyProduct("SharpArch.Core.NHibernateValidator")]
