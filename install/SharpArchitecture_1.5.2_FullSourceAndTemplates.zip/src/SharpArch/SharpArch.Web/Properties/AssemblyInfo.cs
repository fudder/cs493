﻿using System.Reflection;
using System;

[assembly: AssemblyTitle("SharpArch.Web")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyProduct("SharpArch.Web")]
[assembly: CLSCompliant(true)]