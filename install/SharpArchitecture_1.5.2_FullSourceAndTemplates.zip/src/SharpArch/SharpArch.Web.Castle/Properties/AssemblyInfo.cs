﻿using System.Reflection;

[assembly: AssemblyTitle("SharpArch.Web.Castle")]
[assembly: AssemblyProduct("SharpArch.Web.Castle")]
