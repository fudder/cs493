﻿using System.Reflection;

[assembly: AssemblyTitle("SharpArch.Testing")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyProduct("SharpArch.Testing")]