﻿using System.Reflection;
using System;

[assembly: AssemblyTitle("SharpArch.Data")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyProduct("SharpArch.Data")]
[assembly: CLSCompliant(true)]