﻿using System.Reflection;
using System;

[assembly: AssemblyTitle("SharpArch.Tests")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyProduct("SharpArch.Tests")]
[assembly: CLSCompliant(true)]