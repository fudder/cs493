﻿using System.Reflection;
using System;

[assembly: AssemblyTitle("SharpArch.Wcf")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyProduct("SharpArch.Wcf")]
[assembly: CLSCompliant(true)]