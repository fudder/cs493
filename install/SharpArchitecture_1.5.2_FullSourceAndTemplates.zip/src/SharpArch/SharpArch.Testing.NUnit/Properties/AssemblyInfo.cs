﻿using System.Reflection;
using System;

[assembly: AssemblyTitle("SharpArch.Testing.NUnit")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyProduct("SharpArch.Testing.NUnit")]
[assembly: CLSCompliant(true)]