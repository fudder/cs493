﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("SharpArch.WcfClient.Castle")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyProduct("SharpArch.WcfClient.Castle")]
[assembly: Guid("6c1fb396-ca30-4fac-a874-b592eb642ecc")]

