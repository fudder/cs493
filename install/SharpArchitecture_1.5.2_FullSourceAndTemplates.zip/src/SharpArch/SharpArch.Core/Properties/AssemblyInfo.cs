﻿using System.Reflection;
using System;

[assembly: AssemblyTitle("SharpArch.Core")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyProduct("SharpArch.Core")]
[assembly: CLSCompliant(true)]