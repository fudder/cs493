I have submitted the documents through the Drop Boxin this zip, but please 
refer to my project site for the live prototypes, links to the project source,
and for the full CapStone Product documentation:

http://ec2-75-101-182-98.compute-1.amazonaws.com/

Also, please let me know if you have any problems accessing the site.

Thanks!
Patrick Brossard
fudder@hotmail.com